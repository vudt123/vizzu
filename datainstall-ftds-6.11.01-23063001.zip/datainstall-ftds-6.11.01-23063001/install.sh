#!/bin/bash
CP="";
cd ./lib
for file in *
do
  CP="./lib/$file:$CP"
done
echo "$CP"
cd ../
"$JAVA_HOME/bin/java" -classpath $CP ru.diasoft.init.api.execution.MainProcessor $* 
