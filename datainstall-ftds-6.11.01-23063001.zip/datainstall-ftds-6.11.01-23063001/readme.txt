﻿		Инструкция по инициализации продукта
	
	Порядок действий

Для инициализации базы данных запустите файл install.bat [options].

Формат командной строки:

	install.bat [options]

Скрипту инициализации необходимо передавать следующие опции:
			
	--url=<url> - задает JDBC URL для доступа к БД
	--username=<username> - задает имя пользователя, который будет создан и которого следует использовать для соединения с БД 		
	--password=<password> - задает пароль пользователя, по умолчанию: совпадает с именем пользователя
    --<servicename>=<url> - URD Сервиса, метод которого будет вызван. Внимание! наименование параметра (ключ) зависит от конкретной реализации инсталлятора
	--srvLogin=<srvLogin> - логин, который будет использоваться при вызове сервиса.
	--srvPassword=<srvPassword> - пароль к логину srvLogin
	--srvLocale=<srvLocale> - задает локаль, с которой будут пролиты значения

Внимание! Для инициализации БД модуля FLEXTERA "Поддержка принятия решения" необходимо указать путь к сервисам frontws2 и dmsws (как указано в примере).	
	

	Примеры.
	
MSSQL - 
install.bat --url=jdbc:jtds:sqlserver://servername:1243/platform --username=<user> --password=<password> --dmsws=http://localhost:8080/dmsws/dmsws --frontws2=http://localhost:8080/frontws2/frontws2 --srvLogin=tbp --srvPassword=12345678 --srvLocale=ru 1>FTDS.log 2>&1

Oracle - 
install.bat --url=jdbc:oracle:thin:@OracleHost:1521:OracleSID --database=database --username=username --password=password --dmsws=http://localhost:8080/dmsws/dmsws --frontws2=http://localhost:8080/frontws2/frontws2 --srvLogin=tbp --srvPassword=12345678 --srvLocale=ru 1>FTDS.log 2>&1


		Описание файла install.xml

<root> - обязательный родительский тег
	...
	<changeSet - каждый тег означает отдельный вызов сервиса 
		id="<service>PlatformUpdate-X.XX.XX-XX" - идентификатор(должен быть уникальным, поэтому рекомендуется использовать имя сервиса и версию в идентификаторе) 
		name="platform update" - имя (не обязательно)
		author="apopov" - автор 
		class="ru.diasoft.init.api.executors.FrontInit" - класс для вызова сервиса 
		service="frontws2" - имя сервиса(URD должен быть передан при вызове install.bat) 
		command="startInstallation" - * метод сервиса
		params="<параметры>" - ** параметры, с которыми будет вызван метод сервиса
		fileName="FrontPlatformDataUpdate_4.xml" - *** имя файла, содержимое которого будет передано в качестве параметра XMLFILESTRING в метод(актуально только для метода startInstallation)
		comment="pre alfa version - комментарий для записи в базу данных (не обязательно)
	"/>
	...
</root>
* - если используется метод startInstallation, то для него обязательными являются либо XMLFILENAME или XMLFILESTRING.
** - пример атрибута params для метода startInstallation: params="&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;&lt;BODY version=&quot;2.11&quot;&gt;&lt;XMLFILENAME  type=&quot;java.lang.String&quot;&gt;FrontPlatformDataUpdate_4.xml&lt;/XMLFILENAME&gt;&lt;/BODY&gt;"
*** - атрибут fileName используется только если отсутствует	атрибут params. Файл должен быть в формате, обрабатываемом методом startInstallation. 
		Пример можно посмотреть в ресурсах frontservice.