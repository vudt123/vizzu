/*DSMETA version = "5.10.01-23121202" hash = "7dde59d41f9da978a5c12b2ef0ba32d78bf6e514"*/
var lgr = service.lgr;
var nvl = service.nvl;

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
form.formParams.clientInAppMap = inputParams.formParams.clientInAppMap || {};

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
outputParams.formParams.clientInAppMap = form.formParams.clientInAppMap;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE;
form.OfficePhoneNumberMask = form.inputParams.OfficePhoneNumberMask;

form.settings = {

    isRegularEmployment: (form.formParams.clientSocialStatus === 'regularEmployment') || false,

    cmbBorrowerIncomeTypeParams: {
        ReferenceGroupName: 'Loan Origination System',
        ReferenceSysName: 'socialStatusLOS',
        ReferenceItemName: form.formParams.TYPESYSNAME
    },

    cmbIndustryParams: {
        ReferenceGroupName: 'Loan Origination System',
        ReferenceSysName: 'scopeOfActivityUnsecuredLOS',
        ReferenceItemName: 'unsecuredLoanAppINT'
    },

    cmbCompanySizeParams: {
        ReferenceGroupName: 'Loan Origination System',
        ReferenceSysName: 'employeeCountLOS',
        ReferenceItemName: 'unsecuredLoanAppINT'
    },

    cmbLevelParams: {
        ReferenceGroupName: 'Loan Origination System',
        ReferenceSysName: 'clientPositionsLOS',
        ReferenceItemName: 'unsecuredLoanAppINT'
    },

    cmbSalaryPaymentMethodParams: {
        ReferenceSysName: 'methodOfPaymentLOS',
        ReferenceItemName: 'unsecuredLoanAppINT'
    },
    currencyList: [
        {
            ReferenceItemCode: 'VND',
            ReferenceItemBrief: 'VND'
        }
    ],
    currency: 'VND'
};


form.borrowerIncomeTypeOnChange = function () {
    form.settings.isRegularEmployment = (form.formParams.clientSocialStatus === 'regularEmployment') || false;
};


form.templateDataJobFact={
    address:form.formParams.clientJobFactAddress || {},
    addressText:form.formParams.clientJobFactAddressText || "",
    addressRequiredFlag:(form.formParams.clientSocialStatus === 'regularEmployment') || "false",
    addressEnabled:"false",
};

form.templateDataJobLegal={
    address:form.formParams.clientJobLegalAddress || {},
    addressText:form.formParams.clientJobLegalAddressText || "",
    addressRequiredFlag:"false",
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    if (form.isFormEditMode){
        form['adbCurrentWorkAddress'] ? form['adbCurrentWorkAddress'].setValue(form.formParams.clientJobFactAddress) : form['adbCurrentWorkAddress'].setValue(undefined);
        form['adbCompanyAddress'] ? form['adbCompanyAddress'].setValue(form.formParams.clientJobLegalAddress) : form['adbCompanyAddress'].setValue(undefined);
    }
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds("*", showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditMode) {
        form.formParams.clientSocialStatusName = form['cmbBorrowerIncomeType'].getText();
        form.formParams.clientJobSphereOfActivityName = form['cmbIndustry'].getText();
        form.formParams.clientMainJobStaffNumberName = form['cmbCompanySize'].getText();
        form.formParams.methodOfPaymentName = form['cmbSalaryPaymentMethod'].getText();
        //form.formParams.clientJobFactAddress = form['adbCurrentWorkAddress'].getValue();
        //form.formParams.clientJobFactAddressText = form['adbCurrentWorkAddress'].getText();
        //form.formParams.clientJobLegalAddress = form['adbCompanyAddress'].getValue();
       // form.formParams.clientJobLegalAddressText = form['adbCompanyAddress'].getText();
        form.formParams.clientJobFactAddress = form.adbCurrentWorkAddress ? form.adbCurrentWorkAddress.data.address : {};
        form.formParams.clientJobFactAddressText  = form.adbCurrentWorkAddress ? form.adbCurrentWorkAddress.data.address.addressText: "";
        form.formParams.clientJobLegalAddress = form.adbCompanyAddress ? form.adbCompanyAddress.data.address : {};
        form.formParams.clientJobLegalAddressText  = form.adbCompanyAddress ? form.adbCompanyAddress.data.address.addressText: "";
        form.formParams.clientInAppMap.positionBriefText = (form.cmbLevel) ? form.cmbLevel.getText() : "";
        form.formParams.clientJobPhoneNumberText = form['edClientJobPhoneNumber'].getText();

        if(form.formParams.methodOfPayment != 'otherBankAccount'){
            form.formParams.incomeBankName = undefined;
        }

    }
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {

            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};