/*DSMETA version = "5.10.01-23121202" hash = "bcc5a69f964a5b864fcc051cb4831f15bb2ee38a"*/
﻿var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

function registerMethod(initService) {
	var service = {};
	for (var ar in initService) {
		if (initService.hasOwnProperty(ar)) {
			if (ar.indexOf('Service') > -1 || typeof(initService[ar]) != 'function') {
				service[ar] = initService[ar];
			} else {
				var fn = initService[ar].toString();
				var sIdx = fn.search(/\(/) + 1;
				var eIdx = fn.search(/\)\{/);
				var args = fn.substring(sIdx, eIdx)
					eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
			}
		}
	}
	return service;
}
service = registerMethod(service);

var getInputParams = service.getInputParams;
var lgr = service.lgr;
var showAlert = service.showAlert;
var gRBT = service.gRBT;
var gRB = service.gRB;
var nvl = service.nvl;

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

form.data = {
    isMasterFormFlag : Boolean(form.formParams.isMasterFormFlag)
};

form.wizardParams = nvl(getInputParams('wizardParams'), {});
form.preparePath=function(str,project){
	str+="";
	var data=str.split("[");
	if (data.length>1){
		var data2=data[1].split("]");
		return {project:data2[0],pageflow:data2[1]}
	}else{
		return {project:service.nvl(project,form.getCurrentProjectSysname()),pageflow:str}
	}
};

form.onSelectStage = function (item) {
	var params = {
		STAGEID : item.STAGEID,
		CheckRights : "TRUE",
		USERACCOUNTID : getInputParams('USERACCOUNTID'),
		ROLEIDS : getInputParams('ROLEIDS'),
		USERGROUPIDS : getInputParams('USERGROUPIDS')
	};
	if (!form.processingObj.options['ID' + item.STAGEID]) {
		form.dsCall('[frontws2]', 'docProcessingGetById', params).then(function (p) {
			p = p['data']['Result'];

			form.processingObj.options['ID' + item.STAGEID] = p;
			if (p["BUSINESS_ERROR"]) {
				showAlert(p["BUSINESS_ERROR"]);
			}
		});
	}
};

form.processingObj = {
	remoteMethod : {
		filterParams : {
			DOCUMENTID : getInputParams('APPLICATIONID'),
			DISABLE_CLOB : 'TRUE',
			CheckRights : 'TRUE',
			USERACCOUNTID : getInputParams('USERACCOUNTID'),
			ROLEIDS : getInputParams('ROLEIDS'),
			USERGROUPIDS : getInputParams('USERGROUPIDS')
		}
	},
	cols : [{
			value : 'STAGEDATE',
			type : 'datetime',
			caption : ('${processingList.stageDate}'),
			width : 25
		}, {
			value : 'STAGENAME',
			type : 'text',
			caption : ('${processingList.stageName}'),
			width : 25
		}, {
			value : 'STAGERESULT',
			type : 'text',
			caption : ('${processingList.stageResult}'),
			width : 25
		}, {
			value : 'PERFORMER',
			type : 'text',
			caption : ('${processingList.stagePerformer}'),
			width : 25
		}
	],

	options : {
		checkStage : function (item) {
			var rg = new RegExp('ошибка', 'ig');
			return (item.STAGERESULT.search(rg) > -1);
		},
		onShowStage : function (item) {
			var PAGEFLOWNAME       = nvl(item.PAGEFLOWNAME, "");
			var PROCESS_RIGHT_LIST = nvl(getInputParams('PROCESS_RIGHT_LIST'), {});
			var pathkey            = form.getCurrentProjectSysname() + '/COMMON/ADDPANEL/appInfo';
			if (PAGEFLOWNAME!=""){
				var pathData = form.preparePath(item.PAGEFLOWNAME,getInputParams('PROJECT'));
                form.startNewPageFlowProcess(
                    gRBT('viewApplicationStage', item.STAGENAME, item.DOCUMENTNUMBER),
                    pathData.project + "/" + pathData.pageflow,
                    {
                        STAGEID : item.STAGEID,
                        STAGESYSNAME : item.STAGESYSNAME,
                        APPLICATIONID : item.DOCUMENTID,
                        EDITMODE : false,
                        wizardParams : PROCESS_RIGHT_LIST[pathkey].wizardParams,
                        needSaveApp : false
                    },
                    true,
                    undefined
                )
			}
		}
	}
};

form.onShowStage= form.processingObj.options.onShowStage;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.VERIFIED = true;
    outputParams.TRANSTYPE = tagName;
    form.sendForm('GO', false);
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};