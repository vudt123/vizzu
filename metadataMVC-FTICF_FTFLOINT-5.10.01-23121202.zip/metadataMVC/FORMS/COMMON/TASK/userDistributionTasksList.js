/*DSMETA version = "5.10.01-23121202" hash = "1b517fa608f6a1f4f68adabb4d2b44d0ef867514"*/
var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {}
form.formParams = inputParams;

var lgr = service.lgr;
var gRB = function (key) {
    return service.nvl(form.localize[key], key);
};
form.gRB = gRB;

form.action = function (tagName) {
    form.sendForm(tagName);
};
form.onSelectRow = function (item) {
    var bundleName = item.USRSETTINGVALUE == 'ACTIVE' ? "taskList.setInactive" : "taskList.setActive";
    var hItems = [];
        hItems.push({
            caption: form.getResourceBundle(bundleName),
            click: function () {
                var row = form['userDistributionTasksList'].getSelectedRow()[0];
                form.startModalPageFlowProcess(form.getCurrentProjectSysname() + '/COMMON/TASK/userDistributionChange', row).then(function (result) {
                    if (result.tagName=='NEXT') {
                        form['userDistributionTasksList'].refresh();
                    }
                });
            }
        });

    form.taskListObj.options.horizontalMenuItems = hItems;
};

var taskListObj = (function (gridId) {
    var gridId = gridId;
    return {
        options: {
            gRB: gRB,
            horizontalMenuItems: []
        },
        filterParams: inputParams.searchParams,
        element: form[gridId]
    };
})('userDistributionTasksList');
form.taskListObj = taskListObj;
form.executeCommand = function (message) {
    switch (message.event) {
        case 'SEARCH':
            taskListObj.filterParams = message.params;
            form['userDistributionTasksList'].refresh();
            break;
    }
}