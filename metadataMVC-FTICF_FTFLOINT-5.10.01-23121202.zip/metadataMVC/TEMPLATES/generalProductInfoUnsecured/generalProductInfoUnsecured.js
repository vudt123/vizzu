var inputParams = template.data.inputParams;

template.parentForm = template.data.parentForm;
template.inputParams = template.data.parentForm.inputParams || {};
template.formParams = template.data.parentForm.formParams || {};
template.currencyList = template.inputParams.currencyList;
template.editMode = (template.inputParams.EDITMODE === 'YES') || (template.inputParams.EDITMODE+'' == 'true');

template.settings = {
    cmbLoanPurposeParams : {
        ReferenceSysName: 'loanPurpose',
        ReferenceGroupName: 'Loan Origination System',
        ReferenceItemName: 'unsecuredLoanAppINT'
    },
    cmbCurrency:{
        enabled: true
    }
};

template.onShow = function(){
    if (template.currencyList.length == 1) {
        template.formParams.creditCurrencySysName = template.currencyList[0].ReferenceItemBrief;
        template.settings.cmbCurrency.enabled = false;
    }
    template.data.disableLoanPurpose();
    template.getBPparamValues();
};

template.data.disableLoanPurpose = function() {
    if (template.data.needDisableLoanPurpose) {
        template.cmbLoanPurpose ? template.cmbLoanPurpose.disable() : undefined;
    }
};

template.getBPparamValues = function(){

    var PARAMTYPELIST = [
        "interestRateLOS",
        "insurancePremiumRate"
    ];
    var PRODUCTID = template.cmbProductName ? template.cmbProductName.value : "";
    if (!PRODUCTID || !template.editMode) return;
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true
    };
    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){

        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){
                case "interestRateLOS":
                    template.inputParams.interestRateLOS_ITEMS = items["VALUES"] || [];
                    template.formParams.interestRate = template.inputParams.interestRateLOS_ITEMS ? template.inputParams.interestRateLOS_ITEMS[0].VALUE2 : undefined;
                    break;
                case "insurancePremiumRate":
                    template.inputParams.insurancePremiumRate_ITEMS = items["VALUES"] || [];
                    template.formParams.insurancePremiumRate = (template.inputParams.insurancePremiumRate_ITEMS) ? template.inputParams.insurancePremiumRate_ITEMS[0].VALUE1 : undefined;
                    break;
            }
        }
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: form.getResourceBundle("dialog.ok")}]);
    });
};